library(bnlearn)
library(Matrix)
# load dataset(benchmark networks)
#load('C:/Users/student/Desktop/experiment network/asia.rda')
#new_cancer=rbn(bn,500)
#new_loandata=data.frame(new_cancer)
#load XSS dataset(caution: the data of each feature should be at least two leves(two different values), or there will be errors.)
org_data<-read.csv("/home/c2/XSStrain141.csv")
sample1<-sample(nrow(org_data),30000)
data<-org_data[sample1,]
#data<-as.data.frame(lapply(org_data[sample1,],as.character))
#structure<-hc(data,max.iter = 100)
#fitted<-bn.fit(structure,data)
data<-as.matrix(data)
sample2<-sample(nrow(org_data),5000)
test_data<-org_data[sample2,]

#initilize all the parameters
npop<-50   
n<-nrow(data)  
d<-ncol(data)   
pop<-matrix(0,nrow=npop,ncol=d*d)   
e<-1e-8          
h_tol<-Inf      
c<-0.25          
r_max<-1e+16    
max_iter<-100    
fitness_value<-c() 
n_eli<-0.2*npop    
n_mut<-0.2*npop     
tmpop<-matrix(0,nrow=npop-n_eli-n_mut,ncol=d*d) 
new_pop<-matrix(0,nrow=npop,ncol=d*d)  
h_value<-c()

#loss funtion
least_squares_loss<-function(W,data,d,n){     
  #W<-matrix(W,nrow = d,ncol=d,byrow = TRUE)
  #return(1/(2*n)*(base::norm(data-data%*%W))**2)
  return(1/(2*n)*(base::norm(data-data%*%W))**2)
}
least_squares_loss_grad<-function(W,data,d,n){ 
  return((-1.0/n)*(t(data)%*%(data-data%*%W)))
}
L<-function(W){     
  W<-matrix(W,nrow = d,ncol=d,byrow = TRUE)
  return(least_squares_loss(W,data,d,n)+(r/2)*(h(W)**2)+a*(h(W)))
}
L_grad<-function(W){    
  W<-matrix(W,nrow = d,ncol=d,byrow = TRUE)
  return(as.vector(least_squares_loss_grad(W,data,d,n)+h_grad(W)*(a+(r*h(W)))) )
}
h<-function(W){    #constraint condition
  return(sum(diag(Matrix::expm(W*W)))-d)
}
h_grad<-function(W){  
  return(t(Matrix::expm(W*W))*(2*W))
}
adj_convert<-function(W_vector){#??Ⱥ?е???��ת?????ڽӾ???
  W<-matrix(W_vector,nrow=d,ncol=d,byrow=TRUE)
  return(W)
}
vec_convert<-function(W_adj){#convert matrix into vectors
  pop_i<-as.vector(t(W_adj))
  return(pop_i)
}
cross_mating<-function(pop,pe,d,n_eli){   #crossover
  mat_pop<-c()
  r_se<-runif(d*d)
  index_eli<-sample(1:n_eli,1) 
  index_neli<-sample((n_eli+1):npop,1)
  pop1<-pop[index_eli,]
  pop2<-pop[index_neli,]
  for (i_css in 1:(d*d)){
    if(r_se[i_css]<=pe){
      mat_pop[i_css]<-pop1[i_css]
    }
    else{
      mat_pop[i_css]<-pop2[i_css]
    }
  }
  return(mat_pop)
}
mutants<-function(n_mut,d){
  mupop<-matrix(0,nrow=n_mut,ncol=d*d)
  for (i_mut in 1:n_mut) {
    mupop[i_mut,]<-runif(d*d)
  }
  return(mupop)
}
get_W_star<-function(W_list){ #L-BFGS-B
  W<-W_list[[1]]
  r<-W_list[[2]]
  a<-W_list[[3]]
  optim_star<-optim(W,L,L_grad,lower=matrix(0,nrow=d,ncol=d),upper=matrix(1,nrow=d,ncol=d),method = "L-BFGS-B")
  W_star<-optim_star$par
  return(W_star)
}
no_tears<-function(W_list){ #notears algorithm
  for(i in range(max_iter)) {
    while(r<r_max){
      W_star=get_W_star(W_list)
      h_W_star=h(W_star)
      if(h_W_star>0.25*h_tol){
        r<-r*10
      }
      else{ break }
    }
    W<-W_star
    h_tol<-h_W_star
    a<-a+r*h_tol
    W_list<-list(W,r,a)
    if((h_W_star<=e)|(r>=r_max)){
      break
    }
  }
  return(W)
}
legal2<-function(A,nVar){
  C<-A
  for (i in 1:nVar){
    if (sum(diag(C))==0){
      C<-A%*%C
      if ((i==nVar)&&(sum(diag(C))==0)){
        return(A)
      }
    }
    else{
      location=which(C==1,arr.ind = TRUE)
      a<-sample(1:length(location[,"row"]),1)
      row_random<-location[a,"row"]
      for (j in 1:nVar){
        if (A[row_random,j]==1){
          if (row_random==j){
            A[row_random,j]=0
          }
          else{
            A[row_random,j]=0
            A[j,row_random]=1
          }
        }
      }
      A<-legal2(A,nVar)
      C<-A
    }
  }
}
test_acyclic<-function(A,nVar){
  C<-A
  for (i in 1:nVar){
    if (sum(diag(C))==0){
      C<-A%*%C
      if ((i==nVar)&&(sum(diag(C))==0)){
        return(TRUE)
      }else{
        return(FALSE)
      }
    }
  }
}

#main function
for (i in 1:npop) {#generate initial random keys
  pop[i,]<-runif(d*d)
  a<-0.0
  r<-1.0
  W_init<-adj_convert(pop[i,])
  W_list<-list(W_init,r,a)
  W_1<-no_tears(W_list)
  pop[i,]<-vec_convert(W_1)
  #calculate fitness values
  W_1<-adj_convert(pop[i,]) 
  fitness_value[i]<-least_squares_loss(W_1,data,d,n)
}
pop<-pop[order(fitness_value,decreasing = FALSE),]   #sort the population
for (k in 1:max_iter) {
  pop_elite<-pop[1:n_eli,]   #elite population
  pop_non_elite<-pop[(n_eli+1):npop,] #non-elite population
  new_pop[1:n_eli,]<-pop_elite 
  for (i_mat in 1:(npop-n_eli-n_mut)) { 
    tmpop[i_mat,]<-cross_mating(pop,pe,d,n_eli)
  }
  new_pop[(n_eli+1):(npop-n_mut),]<-tmpop 
  mupop<-mutants(n_mut,d)#mutation
  new_pop[(npop-n_mut+1):npop,]<-mupop
  pop<-new_pop
  for (m in (n_eli+1):npop) {
    W_init<-adj_convert(pop[m,])
    a<-0.0
    r<-1.0
    W_list<-list(W_init,r,a)
    W_1<-no_tears(W_list)
    pop[m,]<-vec_convert(W_1)
    #re-calculate the fitness values
    W_1<-adj_convert(pop[m,]) 
    fitness_value[m]<-least_squares_loss(W_1,data,d,n)
  }
  pop<-pop[order(fitness_value,decreasing = FALSE),]   #sort the fitness values
}
threshold_vector<-sort(as.vector(pop[1,]),decreasing = TRUE)
W<-adj_convert(pop[1,])
for (p in 1:d) {
  for (q in 1:d) { 
    if((abs(W[p,q])==0)|(p==q)){
      W[p,q]=0.0
    }else{
      W[p,q]=1.0
    }
  }
}
W<-legal2(W,d)
e = empty.graph(names(org_data))
amat(e)<-W
#XSS detection 
learn_data<-as.data.frame(lapply(org_data[sample1,],as.character))
fitted = bn.fit(e, learn_data)
final_lable<-c()
str_evidence<-list()
str_event<-list()
str_event2<-list()
X30<-c(0,1)
dd <- data.frame(X30)
lable<-0
for (i in 1:5000) {
    str_evidence[i]<-paste("(", names(test_data)[-31], " == '",sapply(test_data[i,-31], as.character), "')",sep = "", collapse = " & ")
    str_event[i]<-paste("(", names(test_data)[31], " == '", as.character(dd[1,1]), "')", sep = "")
    cmd1 = paste("cpquery(fitted, ", str_event[i], ", ", str_evidence[i], ")", sep = "")
    str_event2[i]<-paste("(", names(test_data)[31], " == '", as.character(dd[2,1]), "')", sep = "")
    cmd2= paste("cpquery(fitted, ", str_event2[i], ", ", str_evidence[i], ")", sep = "")
    if(eval(parse(text = cmd1))>eval(parse(text = cmd2))){
    final_lable[i]<-"0"
  }else{
    final_lable[i]<-"1"
  }
}
for (z in 1:5000) {
  if(final_lable[z]==test_data[z,31]){
    lable<-lable+1
  }
}
lable



