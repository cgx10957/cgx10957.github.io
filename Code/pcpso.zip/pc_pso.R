library(bnlearn)
#mutation operator
Mutate3<-function(j,pop,w,nVar){
  additionRate=0.5
  deletionRate=additionRate/(1+additionRate)
  M=pop$position[[j]]
  #maximum indegree
  max_indegree<-c()
  for (i in 1:nVar) {
    count_indegree<-0
    for (j in 1:nVar) {
      if(M[j,i]!=0){
        count_indegree<-count_indegree+1
      }
    }
    max_indegree[i]<-count_indegree
  }
  max_indegree<-sort(max_indegree,decreasing = TRUE)
  max_inresult<-max_indegree[1]
  M<-t(M)
  initial_popc=as.vector(M)
  mm=0.5
  if(runif(1,0,1)<w){
    for (k in 1:nVar*nVar){
      if (runif(1,0,1)<additionRate){
        if (round(runif(1,0,1))<mm){
          newgene<-1
        }
        else{
          newgene<-1
        }
        if (runif(1,0,1)<0.5){
          if (k==1){
            initial_popc<-c(newgene,initial_popc)
          }
          else{
            initial_popc<-append(initial_popc,newgene,k-1)
          }
        }
        else{
          initial_popc<-append(initial_popc,newgene,k)
        }
      }
    }
    a=length(initial_popc)
    while (a!=nVar*nVar){
      if (runif(1,0,1)<deletionRate){
        initial_popc<-initial_popc[-k]
        #print(initial_popc)
      }
      a=length(initial_popc)
    }
  }
  M_pop<-matrix(initial_popc,nrow=nVar,ncol=nVar)
  M_pop<-t(M_pop)
  #maximum indegree
  max_indegree_pop<-c()
  for (m in 1:nVar) {
    count_indegree_pop<-0
    for (k in 1:nVar) {
      if(M[k,m]!=0){
        count_indegree_pop<-count_indegree_pop+1
      }
    }
    max_indegree_pop[i]<-count_indegree_pop
  }
  max_indegree_pop<-sort(max_indegree_pop,decreasing = TRUE)
  max_inresult_pop<-max_indegree_pop[1]
  if(max_inresult_pop<=max_inresult){
    return(M_pop)
  }
  else{
    return(M)
  }
}
#acyclicity 
legal2<-function(A,nVar){
  C<-A
  for (i in 1:nVar){
    if (sum(diag(C))==0){
      C<-A%*%C
      if ((i==nVar)&&(sum(diag(C))==0)){
        return(A)
      }
    }
    else{
      location=which(C==1,arr.ind = TRUE)
      a<-sample(1:length(location[,"row"]),1)
      row_random<-location[a,"row"]
      for (j in 1:nVar){
        if (A[row_random,j]==1){
          if (row_random==j){
            A[row_random,j]=0
          }
          else{
            A[row_random,j]=0
            A[j,row_random]=1
          }
        }
      }
      A<-legal2(A,nVar)
      C<-A
    }
  }
}
#crossover��local best solution��
Crossover1<-function(k,popc,particle_Best,c1,nVar){
  newpop1<-c()
  if (runif(1,0,1)<c1){
    initial_pop1<-popc$position[[k]]
    initial_pop2<-particle_Best$position[[k]]
    initial_pop1<-t(initial_pop1)
    initial_pop2<-t(initial_pop2)
    initial_pop1=as.vector(initial_pop1)
    initial_pop2=as.vector(initial_pop2)
    rand_index=sample(length(initial_pop1))
    a=sample(length(initial_pop1),1)
    draw_rand_index=rand_index[1:a]
    for (i in 1:length(draw_rand_index)) {
      newpop1[draw_rand_index[i]]=initial_pop1[draw_rand_index[i]]
    }
    for (j in 1:length(initial_pop1)){
      if (j %in% draw_rand_index){
        next
      }
      else{
        newpop1[j]=initial_pop2[j]
      }
    }
    newpop1<-matrix(newpop1,nrow=nVar,ncol=nVar)
    newpop1<-t(newpop1)
  }
  else{
    newpop1=popc$position[[k]]
  }
  return(newpop1)
}
#crossover��global best solution��
Crossover2<-function(m,popc,GlobalBest,c2,nVar){
  newpop2<-c()
  if (runif(1,0,1)<c2){
    initial_pop3<-popc$position[[m]]
    initial_pop4<-GlobalBest$position
    initial_pop3<-t(initial_pop3)
    initial_pop4<-t(initial_pop4)
    initial_pop3=as.vector(initial_pop3)
    initial_pop4=as.vector(initial_pop4)
    rand_index=sample(length(initial_pop3))
    a=sample(length(initial_pop3),1)
    draw_rand_index=rand_index[1:a]
    for (i in 1:length(draw_rand_index)) {
      newpop2[draw_rand_index[i]]=initial_pop3[draw_rand_index[i]]
    }
    for (j in 1:length(initial_pop3)){
      if (j %in% draw_rand_index){
        next
      }
      else{
        newpop2[j]=initial_pop4[j]
      }
    }
    newpop2<-matrix(newpop2,nrow=nVar,ncol=nVar)
    newpop2<-t(newpop2)
  }
  else{
    newpop2=popc$position[[m]]
  }
  return(newpop2)
}
#main program
nVar=8
MaxIt=100
nPop=50
nrow=1
ncol=50

#initialization
row_name<-vector(mode="numeric")
col_name<-vector(mode="numeric")

Position<-list()
Score<-matrix(nrow=nrow,ncol=ncol)
Position2<-list()
Score2<-matrix(nrow=nrow,ncol=ncol)

pop<-list(position=Position,score_dag=Score)

particle_Position<-list()
particle_Score<-matrix(nrow=nrow,ncol=ncol)
particle_Velocity<-list()
particle<-list(particle_Position,particle_Score,particle_Velocity)

particle_Best_Position=list()
particle_Best_Score=matrix(nrow=nrow,ncol=ncol)
particle_Best<-list(position=particle_Best_Position,score_dag=particle_Best_Score)

GlobalBest_Score=-100000
GlobalBest_Position=matrix(nrow=nVar,ncol=nVar)

GlobalBest=list(GlobalBest_Score,GlobalBest_Position)
# load dataset
load('C:/Users/student/Desktop/experiment network/asia.rda')
new_cancer=rbn(bn,500)
new_loandata=data.frame(new_cancer)

names(new_loandata)<-c(1:nVar)
BestScore<-c()
order_score<-c()
sort_score<-c()
empty_position<-new_loandata
#structure priors(pc algorithm)
m=pc.stable(new_loandata)
new_m=amat(m)
a=1
for (i in 1:nVar)
  for(j in 1:nVar)
    if ((new_m[i,j]==1)&&(new_m[j,i]==0)){
      row_name[a]=i
      col_name[a]=j
      a=a+1
    }

#generate the first population
load('C:/Users/student/Desktop/experiment network/asia.rda')
new_cancer=rbn(bn,500)
new_loandata=data.frame(new_cancer)
name_varaiable=names(new_loandata)
for (k in 1:50){
  e=random.graph(name_varaiable)
  dag=amat(e)#�ڽӾ���
  for (p in 1:length(row_name)){
   dag[row_name[p],col_name[p]]=1
  }
  dag<-legal2(dag,nVar)
  Position[[k]]=dag#initial solution
  dg0=empty.graph(name_varaiable)
  amat(dg0)<-dag
  Score[nrow,k]<-score(dg0,new_loandata,type="bic")#scores
  pop<-list(position=Position,score_dag=Score)

  particle_Position[[k]]= Position[[k]]
  particle_Score[[k]]=Score[[k]]
  particle<-list(position=particle_Position,score_dag=particle_Score,velocity=particle_Velocity)
  #update the particle best solution
  particle_Best_Position[[k]]=particle_Position[[k]]
  particle_Best_Score[[k]]=particle_Score[[k]]
  particle_Best<-list(position=particle_Best_Position,score_dag=particle_Best_Score)
  if (particle_Best_Score[[k]]>=GlobalBest_Score){
    GlobalBest_Position=particle_Best_Position[[k]]
    GlobalBest_Score=particle_Best_Score[[k]]
    GlobalBest=list(position=GlobalBest_Position,score_dag=GlobalBest_Score)
    }
}
order_score<-order(pop$score_dag,decreasing = TRUE)
sort_score<-sort(pop$score_dag,decreasing=TRUE)
pop$position<-pop$position[order_score]
BestSol<-list(position=pop$position[[1]],score_dag=pop$score_dag[[1]])
GlobalBest<-BestSol
BestScore<-matrix(0,nrow=MaxIt,ncol = 1)

w_start=0.9
w_end=0.35
c1_start=0.84
c1_end=0.52
c2_start=0.38
c2_end=0.81
Cx<-c()
popc<-list()

for (it in 1:MaxIt){
  w=w_start-(w_start-w_end)*it/MaxIt
  c1=c1_start-(c1_start-c1_end)*it/MaxIt
  c2=c2_start-(c2_start-c2_end)*it/MaxIt
  #mutate
  for (j in 1:nPop){
    popc$position[[j]]<-Mutate3(j,pop,w,nVar)
    A=popc$position[[j]]
    popc$position[[j]]<-legal2(A,nVar)
    C<-popc$position[[j]]
    dg=empty.graph(name_varaiable)
    amat(dg)<-C
    popc$score_dag[[j]]=score(dg,new_loandata,type="bic")
    particle$velocity[[j]]=popc$position[[j]]
  }
  #crossover
  for (k in 1:nPop) {
    popc$position[[k]]=Crossover1(k,popc,particle_Best,c1,nVar)
    D<-popc$position[[k]]
    popc$position[[k]]=legal2(D,nVar)
    D<-popc$position[[k]]
    dg2=empty.graph(name_varaiable)
    amat(dg2)<-D
    all.equal(D,dg2)
    popc$score_dag[[k]]=score(dg2,new_loandata,type="bic")
  }
  #crossover
  for (m in 1:nPop) {
    popc$position[[m]]=Crossover2(m,popc,GlobalBest,c2,nVar)
    E<-popc$position[[m]]
    popc$position[[m]]=legal2(E,nVar)
    E<-popc$position[[m]]
    dg3=empty.graph(name_varaiable)
    amat(dg3)<-E
    popc$score_dag[[m]]=score(dg3,new_loandata,type="bic")
    particle$position[[m]]=popc$position[[m]]#��������λ��
  }
  #merge pop and popc
  Position2<-c(pop$position,popc$position)
  Score2<-c(pop$score_dag,popc$score_dag)
  pop<-list(position=Position2,score_dag=Score2)
  #select the first 50 individuals
  order_score<-order(pop$score_dag,decreasing = TRUE)
  sort_score<-sort(pop$score_dag,decreasing=TRUE)
  pop$position<-pop$position[order_score]
  pop<-list(position=pop$position,score_dag=sort_score)
  pop1<-list()
  for (r in 1:nPop){
    pop1$position[[r]]<-pop$position[[r]]
    pop1$score_dag[[r]]<-pop$score_dag[[r]]
  }
  pop<-pop1
  BestSol<-list(position=pop$position[[1]],score_dag=pop$score_dag[[1]])
  #update parameters of particles
  
  for (n in 1:nPop) {
    if (pop$score_dag[[n]]>=particle$score_dag[[n]]){
      particle$position[[n]]=pop$position[[n]]
      particle$score_dag[[n]]=pop$score_dag[[n]]
    }
    Cx[n]=particle$score_dag[[n]]
  }
  r<-which.max(particle$score_dag)
  BestScore[it]=max(Cx)
  GlobalBest$score_dag=particle$score_dag[[r]]
  GlobalBest$position=particle$position[[r]]
  ##update parameters of particles
  for (num in 1:nPop){
    particle$velocity[[num]]=particle$velocity[[num]]
    particle$position[[num]]=particle$position[[num]]
    G<-particle$position[[num]]
    #G<-legal2(G,nVar)
    dg4=empty.graph(name_varaiable)
    amat(dg4)<-G
    particle$score_dag[[num]]=score(dg4,new_loandata,type="bic")
    #update the best solutions of particles
    if (particle$score_dag[[num]]>particle_Best$score_dag[[num]]){
      particle_Best$position[[num]]=particle$position[[num]]
      particle_Best$score_dag[[num]]=particle$score_dag[[num]]
      if (particle_Best$score_dag[[num]]>GlobalBest$score_dag){
        GlobalBest$position=particle_Best$position[[num]]
        GlobalBest$score_dag=particle_Best$score_dag[[num]]
      }
    }
    
  }
  for (num2 in 1:nPop) {
    if (particle$score_dag[[num2]]>=pop$score_dag[[num2]]){
      pop$position[[num2]]=particle$position[[num2]]
      pop$score_dag[[num2]]=particle$score_dag[[num2]]
    }
    Cx[num2]=pop$score_dag[[num2]]
  }
  r2<-which.max(particle$score_dag)
  BestScore[it]=max(Cx)
  GlobalBest$score_dag=pop$score_dag[[r2]]
  GlobalBest$position=pop$position[[r2]]
}
