/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package agena2bnt;

import java.util.List;
import uk.co.agena.minerva.model.Model;
import uk.co.agena.minerva.model.extendedbn.ExtendedBN;
import uk.co.agena.minerva.model.extendedbn.ExtendedBNException;
import uk.co.agena.minerva.model.extendedbn.LabelledEN;
import uk.co.agena.minerva.util.io.FileHandlingException;
import java.io.*;
import java.util.Arrays;

/**
 *
 * @author yz300
 * This java code is for converting the Agenarisk model to BNT model.
 */
public class Agena2bnt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileHandlingException, ExtendedBNException, IOException {
        // TODO code application logic here
        Model      m     = Model.load("Asia.ast");
        ExtendedBN ebn   = m.getExtendedBNAtIndex(0);
        List       nlist = ebn.getExtendedNodes();
        
        // Output in BNT matlab.m file
        FileWriter     fstream = new FileWriter("mk_agena_bnet.m");
        BufferedWriter fout    = new BufferedWriter(fstream);
        fout.write("function bnet = mk_agena_bnet()");
        fout.newLine();
        fout.write("n = " + nlist.size() + ";");
        
        // Get the structure information
        fout.newLine();
        fout.write("dag = zeros(n);");
        for (int i = 0; i < nlist.size(); i++) {
            LabelledEN ln    = (LabelledEN) nlist.get(i);
            List       clist = ebn.getChildNodes(ln);
            if (clist.isEmpty()) {
                // Leaf nodes (no children)
            } else {
                int[] cindices = new int[clist.size()];
                for (int c = 0; c < clist.size(); c++) {
                    LabelledEN cn = (LabelledEN) clist.get(c);
                    cindices[c]   = nlist.indexOf(cn)+1;
                }
                fout.newLine();
                fout.write("dag(" + (i+1) + ", " + Arrays.toString(cindices) + ") = 1;");
            }
        }
        
        // Get the node states
        int[] ns = new int[nlist.size()];
        for (int i = 0; i < nlist.size(); i++) {
            LabelledEN ln = (LabelledEN) nlist.get(i);
            ns[i]         = ln.getExtendedStates().size();
        }
        fout.newLine();
        fout.write("ns = " + Arrays.toString(ns) + ";");
        fout.newLine();
        fout.write("dnodes = 1:n;");
        fout.newLine();
        fout.write("bnet = mk_bnet(dag, ns, 'discrete', dnodes);");
        
        
        // Get the CPTs used in BNT
        for (int i = 0; i < nlist.size(); i++) {
            LabelledEN ln    = (LabelledEN) nlist.get(i);            
            float[][] lnNPT  = ln.getNPT();
            float[]   newNPT = new float[lnNPT.length*lnNPT[0].length];
            for (int j = 0; j < lnNPT.length; j++) {
                System.arraycopy(lnNPT[j], 0, newNPT, j*lnNPT[0].length, lnNPT[0].length);
            }
            fout.newLine();
            fout.write("bnet.CPD{" + (i+1) + "} = tabular_CPD(bnet, " + (i+1) + ", " + Arrays.toString(newNPT) + ");");         
        }
        fout.close();
    }
    
}
